package ejercicio5;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class CalculadoraTest {

    @Test
    public void testDividir() {
        Calculadora calc = new Calculadora();
        
        
        double esperado = 5.0;
        double real = calc.dividir(10.0, 2.0);
        
        assertEquals(esperado, real, "La división de 10 entre 2 debe ser 5");
    }

    @Test
    public void testDividirPorCero() {
        Calculadora calc = new Calculadora();
        
       
        assertEquals(0.0, calc.dividir(10.0, 0.0), "La división por cero debe retornar 0.0");
    }
}