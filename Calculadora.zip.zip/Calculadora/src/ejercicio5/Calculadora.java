package ejercicio5;

/**
 * Ejercicio 5: Código totalmente refactorizado.
 * Se han eliminado "Code Smells" de nombres genéricos y números mágicos.
 * * @author Ivan del cid 
 * @version 2.0
 */
public class Calculadora {

   
    private static final double VALOR_POR_DEFECTO_ERROR = 0.0;

    /**
     * Realiza la división entre dos números con validación de seguridad.
     * * @param dividendo El número que se divide (antes n1)
     * @param divisor El número por el que se divide (antes n2)
     * @return El cociente de la operación
     */
    public double dividir(double dividendo, double divisor) {
        
       
        if (divisor == 0) {
            System.err.println("Error: No se puede dividir por cero.");
            return VALOR_POR_DEFECTO_ERROR;
        }
        
        return dividendo / divisor;
    }
}
/*
 * RESPUESTAS TEÓRICAS - EJERCICIO 5 
 * --------------------------------------------------------
 * 1. IDENTIFICACIÓN DE CODE SMELLS:
 * -Se detectaron variables poco claras (n1, n2).
 * -Uso de valores literales directos en la lógica.
 * * 2. REFACTORIZACIONES REALIZADAS:
 * -Se han renombrado variables a 'dividendo' y 'divisor' para mejorar la legibilidad.
 * -Se ha creado la constante VALOR_POR_DEFECTO_ERROR para evitar números mágicos.
 * -Se ha añadido una validación al inicio del método para gestionar el error de división por cero.
 */