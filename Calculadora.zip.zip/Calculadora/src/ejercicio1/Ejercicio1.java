package ejercicio1;

public class Ejercicio1 {

    public static void main(String[] args) {
        double radio = 5.0;

        double area = calcularAreaCirculo(radio);
        imprimirResultado(area);
    }

   
    public static double calcularAreaCirculo(double radio) {
        return Math.PI * Math.pow(radio, 2);
    }

    
    public static void imprimirResultado(double valor) {
        System.out.println("El resultado de la operación es: " + valor);
    }
}