package ejercicio4;

/**
 * Clase que proporciona métodos para realizar operaciones aritméticas.
 * Esta clase es parte de la práctica de los Temas 9 y 10 de Entornos de Desarrollo.
 * * @author Ivan Del cic
 * @version 1.0
 */
public class Calculadora {

    /**
     * Realiza la división de dos números decimales.
     * * @param num1 El dividendo (número que será dividido).
     * @param num2 El divisor (debe ser distinto de cero para evitar errores).
     * @return El cociente resultante de la división.
     * @throws ArithmeticException Si se intenta dividir por cero (opcional según el código).
     */
    public double dividir(double num1, double num2) {
        if (num2 == 0) {
            System.out.println("Error: Divisor es cero");
            return 0;
        }
        return num1 / num2;
    }
}