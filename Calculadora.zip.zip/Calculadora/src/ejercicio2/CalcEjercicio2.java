package ejercicio2;

public class CalcEjercicio2 {

    public static void main(String[] args) {
        
        double precioProducto = 19.99;
        
        
        int cantidadUnidades = 3;

        
        
        double totalFactura = calcularTotal(precioProducto, cantidadUnidades);
        
        System.out.println("Total a pagar: " + totalFactura);
    }

    
    public static double calcularTotal(double precio, int cantidad) {
        return precio * cantidad;
    }
}
