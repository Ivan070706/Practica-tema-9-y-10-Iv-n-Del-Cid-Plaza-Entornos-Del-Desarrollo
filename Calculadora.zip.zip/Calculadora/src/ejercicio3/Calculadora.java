package ejercicio3;

public class Calculadora {
    public int dividir(int num1, int num2) {
        if (num2 == 0) {
            throw new IllegalArgumentException("No se puede dividir por cero");
        }
        return (int) (num1 / num2);
    }

	

}
