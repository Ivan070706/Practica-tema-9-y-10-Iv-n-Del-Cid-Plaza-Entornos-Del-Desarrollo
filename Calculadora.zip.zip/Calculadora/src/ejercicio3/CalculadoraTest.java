package ejercicio3;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class CalculadoraTest {

    @Test
    public void testDividirPositivos() {
        Calculadora calc = new Calculadora();
        
        // Queremos ver si 10 / 2 da 5.0
        double resultadoEsperado = 5.0;
        double resultadoReal = ((Calculadora) calc).dividir(10, 2);
        
        assertEquals(resultadoEsperado, resultadoReal, "La división de 10/2 debería ser 5");
    }

    @Test
    public void testDividirNegativos() {
        Calculadora calc = new Calculadora();
        // Verificamos que -6 / 3 da -2.0
        assertEquals(-2.0, calc.dividir(-6, 3));
    }
}